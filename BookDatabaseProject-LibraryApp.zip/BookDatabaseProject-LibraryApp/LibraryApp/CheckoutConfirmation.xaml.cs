﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryApp
{
    /// <summary>
    /// Interaction logic for CheckoutConfirmation.xaml
    /// </summary>
    public partial class CheckoutConfirmation : Window
    {
        List<Book> CheckingBooks { get; set; }
        ObservableCollection<Book> BookCollection = XMLHandler.ReadBooksFromMemory();
        public CheckoutConfirmation(List <Book> checkingBooks)
        {
            InitializeComponent();
            CheckingBooks = checkingBooks;
            BookList.ItemsSource = CheckingBooks;
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            int countOfBooks = 0;
            string messageString = "";

            foreach(Book b in BookCollection.ToList())
            {
                string[] data = b.CurrentOwner.Split('|');
                foreach (string s in data)
                {
                    if (s == MainWindow.CurrentUser.ID.ToString())
                    {
                        countOfBooks++;
                    }
                }
            }

            foreach (Book b in CheckingBooks)
            {
                foreach(Book bb in BookCollection.ToList())
                {
                    if (b.Title == bb.Title && b.AuthorFirstName == bb.AuthorFirstName && b.AuthorLastName == bb.AuthorLastName && b.Publisher == bb.Publisher) //if the two books are equal
                    {
                        string[] data = bb.CurrentOwner.Split('|');
                        bool isValid = true;
                        foreach (string s in data)
                        {
                            if (s == MainWindow.CurrentUser.ID.ToString())
                            {
                                isValid = false;
                                messageString += ("You have current either checked out or are on the waitlist for: " + bb.Title + "\n\n");
                            }
                        }
                        if (isValid)
                        {
                            countOfBooks++;
                            if (countOfBooks > 10)
                            {
                                messageString += ("Sorry, you cannot checkout: " + bb.Title + " because you have already checked out 10 books");
                            }
                            else if (bb.CurrentOwner == "")  //This means no one has checked out the book
                            {
                                bb.CurrentOwner = MainWindow.CurrentUser.ID.ToString();
                                messageString += ("Checkout Confirm for: " + bb.Title + "\n\n");
                            }
                            else //this means the book is currently checked out
                            {
                                bb.CurrentOwner += ("|" + MainWindow.CurrentUser.ID.ToString());
                                messageString += ("Added to the waitlist for: " + bb.Title + "\n\n");
                            }
                        }
                    }
                }
            }
            XMLHandler.WriteToXML(BookCollection);
            MessageBox.Show(messageString);
            this.Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
