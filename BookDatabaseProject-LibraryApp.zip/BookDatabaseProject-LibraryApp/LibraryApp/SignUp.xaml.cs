﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;

namespace LibraryApp
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Window
    {
        //public ObservableCollection<User> Users { get; set; } = MainWindow.UserCollection;
        XmlSerializer serializer = new XmlSerializer(typeof(List<User>));

        public SignUp()
        {
            MainWindow.UserCollection = XMLHandler.ReadUsersFromMemory();
            InitializeComponent();
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            int id = MainWindow.UserCollection.Count() + 1;

            IEnumerable<User> query1 = MainWindow.UserCollection.Where(x => x.Username == UserEntry.Text);

            // The loop below ensures that no two users will share the same ID#

            if (ValidateEntries())
            {
                if (query1.Count() == 0)
                {
                    User account = new User(UserEntry.Text, PasswordEntry.Password, NameEntry.Text, id);
                    MainWindow.UserCollection.Add(account);
                    XMLHandler.WriteToXML(MainWindow.UserCollection);


                    MessageBox.Show("Account has been created", "Success");
                    Login win = new Login();
                    win.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Username already taken. Please choose another.", "Duplicate User");
                }
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            Login win = new Login();
            win.Show();
            this.Close();
        }

        private bool ValidateEntries()
        {
            if (string.IsNullOrWhiteSpace(UserEntry.Text)) { return false; }
            if (string.IsNullOrWhiteSpace(NameEntry.Text)) { return false; }
            if (string.IsNullOrWhiteSpace(PasswordEntry.Password)) { return false; }

            if (PasswordEntry.Password != ConfirmEntry.Password)
            {
                MessageBox.Show("Error. Passwords do not match. Please re-enter.", "Confirm Password Failure");
                return false;
            }

            return true;

        }
    }
}
