﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LibraryApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static ObservableCollection<Book> BookCollection = new ObservableCollection<Book>();
        public static ObservableCollection<User> UserCollection = new ObservableCollection<User>();
        List<string> GenreOptions = new List<string> { "Science Fiction", "Satire", "Action and Adventure", "Romance", "Horror", "Mystery", "Non-Fiction", "Poetry" };
        public static User CurrentUser = new User();
        public List<Book> userBooks { get; set; }
        public List<Book> userRequestedBooks { get; set; }

        public MainWindow()
        {
            InitializeComponent();


            try { BookCollection = XMLHandler.ReadBooksFromMemory(); } //Book Collection is now populated with what is in Book.xml
            catch (Exception ex)
            {
                Console.WriteLine("******* Unable to read xml file*********", ex.InnerException);
                MessageBox.Show($"Unable to read xml file\nInner Exception:{ex.InnerException.Message}");
            }

            XMLHandler.WriteToXML(BookCollection); //Writes list of books to Book.xml

            UpdateLists();
        }

        private void BookSearch_Click(object sender, RoutedEventArgs e)
        {
            BookSearch search = new BookSearch();
            search.ShowDialog();
            UpdateLists();
        }
       
        private void BookRequest_Click(object sender, RoutedEventArgs e)
        {
            BookRequest request = new BookRequest();
            request.ShowDialog();
            UpdateLists();
        }

        public void UpdateLists()
        {
            BookCollection = XMLHandler.ReadBooksFromMemory();
            UserCollection = XMLHandler.ReadUsersFromMemory();
            var userBooksQuerey = from Book b in BookCollection  //Now the search will only let you search through books currently in the database system
                            where b.InLibrary == 1 && b.CurrentOwner == CurrentUser.ID.ToString()
                            select b;

            userBooks = userBooksQuerey.ToList();

            userRequestedBooks = new List<Book>();
            string[] data;

            foreach (Book b in BookCollection.ToList())
            {
                data = b.CurrentOwner.Split('|');
                if (data.Length > 1)
                {
                    if (data[0] == CurrentUser.ID.ToString())
                    {
                        userBooks.Add(b);
                    }
                    else
                    {
                        foreach (String s in data.Skip(1)) //We skip 1 because if the user is the first result in data[] then he has it checked out, not waitlisted
                        {
                            if (s == CurrentUser.ID.ToString())
                            {
                                userRequestedBooks.Add(b);
                            }
                        }
                    }
                }
            }
            CheckedOutList.ItemsSource = userBooks;
            WaitlistList.ItemsSource = userRequestedBooks;
            CheckedOutList.Items.Refresh();
            WaitlistList.Items.Refresh();
        }

        private void Logout_click(object sender, RoutedEventArgs e)
        {
            MainWindow.CurrentUser = new User(); //Refreshes the user to be blank
            Login win = new Login();
            win.Show();
            this.Close();
        }

        private void ExitProgram_click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Info_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("A library database project created by Rohan Bhuyan and Blanette Baltimore \n  This is the main User Profile Page where Users can see currently checked out books and books they're on the waitlist for");
        }

        private void RemoveFromWaitlist_Click(object sender, RoutedEventArgs e)
        {
            BookCollection = XMLHandler.ReadBooksFromMemory();
            UserCollection = XMLHandler.ReadUsersFromMemory();
            Book selectedBook = (Book)WaitlistList.SelectedItem;
            if (selectedBook == null)
            {
                MessageBox.Show("Please select a book from the above list");
            }
            else
            {
                foreach(Book b in BookCollection.ToList())
                {
                    if (b.Title == selectedBook.Title && b.AuthorFirstName == selectedBook.AuthorFirstName && b.AuthorLastName == selectedBook.AuthorLastName && b.Publisher == selectedBook.Publisher && b.InLibrary == 1)
                    {
                        //If we have reached here this means we have found the book in the xml file that corresponds to the selected book
                        string bookowners = b.CurrentOwner;
                        string userString = ("|" + CurrentUser.ID.ToString());
                        bookowners = bookowners.Replace(userString, ""); //Finds the place where "||<CURRENTUSERID>" appears in the CurrentOwner property of the book we're looking at, replaces it with an empty string
                        bookowners = bookowners.Replace("||", "|"); //Replaces duplicate || in an edge case of the user being the last person on the waitList
                        b.CurrentOwner = bookowners;
                    }
                }
                XMLHandler.WriteToXML(BookCollection);
                UpdateLists();
            }
        }
    }
}
