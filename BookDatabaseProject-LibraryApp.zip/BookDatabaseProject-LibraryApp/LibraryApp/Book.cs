﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace LibraryApp
{
    [XmlRoot(ElementName = "Book")]
    public class Book
    {
        [XmlAttribute(DataType = "string")]
        public string Title { get; set; }

        [XmlAttribute(DataType = "string")]
        public string AuthorLastName { get; set; }

        [XmlAttribute(DataType = "string")]
        public string AuthorFirstName { get; set; }

        [XmlAttribute(DataType = "string")]
        public string Genre { get; set; }

        [XmlAttribute(DataType = "string")]
        public string Publisher { get; set; }

        [XmlAttribute(DataType = "int")] // 1 if it is library and 0 if requested
        public int InLibrary { get; set; }

        [XmlAttribute(DataType = "string")]
        public string CurrentOwner { get; set; } // Displays who currently has book checked out

        public Book() { }

        public Book(string title, string authorLastName, string authorFirstName, string genre, string publisher, int inLibrary, string currentOwner)
        {
            Title = title;
            AuthorLastName = authorLastName;
            AuthorFirstName = authorFirstName;
            Genre = genre;
            Publisher = publisher;
            InLibrary = inLibrary;
            CurrentOwner = currentOwner;
        }

        public override string ToString()
        {
            if (AuthorLastName != "N/A")
            {
                return $"{Title}\nby {AuthorFirstName} {AuthorLastName}\n{Genre}";
            }
            else
                return $"{Title}\nby {AuthorFirstName}\n{Genre}";
        }
 
        public static ObservableCollection<Book> ReadCSV()  //Reads the csv into an xml file
        {
            ObservableCollection<Book> temp = new ObservableCollection<Book>();
            string[] lines = File.ReadAllLines(@".\books.csv");

            foreach (string line in lines.Skip(1)) //Skip 1 because it contains the parameter names of the csv file
            {
                try      //Some books in the csv file are not formatted correctly but we have enough of a sample size where we can just throw these anomalies out instead of handling each edge case
                {
                    string[] data = line.Split(',');

                    data[0] = data[0].Replace("&", "and"); //Replaces all instances of & (a unique UTF char that is not read normally) with and
                    

                    Book b = new Book(data[0], data[1], data[2], data[3], data[5], 1, ""); //We set the bool value to true because by reading in the books for the library database we know these books are in the library
                    temp.Add(b);
                }
                catch (Exception ex)
                {
                    Console.Write("Error in parsing through CSV file, Eception: " + ex);
                    //Just ignore this
                }
            }
            return temp;
        }
    }
}

