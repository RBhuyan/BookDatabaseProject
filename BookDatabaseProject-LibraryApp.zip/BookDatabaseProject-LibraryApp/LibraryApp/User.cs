﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace LibraryApp
{
    [XmlRoot(ElementName = "User")]
    public class User
    {
        [XmlAttribute(DataType = "string")]
        public string Username { get; set; }

        [XmlAttribute(DataType = "string")]
        public string Password { get; set; }

        [XmlAttribute(DataType = "string")]
        public string Name { get; set; }

        [XmlAttribute(DataType = "int")]
        public int ID { get; set; }


        public User() { } //Default constructor for User creation with empty paramters

        public User(string username, string password, string name, int id)
        {
            Username = username;
            Password = password;
            Name = name;
            ID = id;
        }
    }
}
