﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LibraryApp
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public User editingUser = new User();
        public ObservableCollection<User> userList = XMLHandler.ReadUsersFromMemory(); //Contains the complete list of users in xml database
        public Login()
        {
            InitializeComponent();

        }

        private void ExitProgram_click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Help_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("This is the student database project login screen");
        }

        private void Login_click(object sender, RoutedEventArgs e)
        {
            if (Login_authenticate())
            {
                MainWindow.CurrentUser = editingUser;
                MainWindow win = new MainWindow();
                win.Show();
                this.Close(); //Opens up user profile, closes login window
            }
            else
            {
                MessageBox.Show("Incorrect username or password. Make sure you typed your account details correctly or consider registering a new account");
            }
        }

        private bool Login_authenticate()
        {
            var currentUsers = from s in userList
                               where (s.Username == usernameInput.Text && s.Password == passwordInput.Password)
                               select s;
            if (currentUsers.Count() == 0)  //This means there were no Users in User.xml where the username and password matched  
            {
                return false;
            }

            else
            {
                foreach(User u in currentUsers)
                {
                    editingUser = u;
                }
            }
            return true;
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            SignUp win = new SignUp();
            win.Show();
            this.Close(); //Opens up user profile, closes login window
        }

        private void Info_click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("A Library Database WPF Midterm Project made my Rohan Bhuyan and Blanette Baltimore \n\nAllows users to login/sign up and either check out books or place themselves on waitlists \n\nFor ease of use an already registered user is:\n\nUsername:\tuu\nPassword:\tpp");
        }
    }
}
